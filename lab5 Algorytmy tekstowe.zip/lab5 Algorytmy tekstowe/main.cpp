#include <iostream>
#include <string>
#include <cstring>

using namespace std;

void zadanie5_1(string& wzorzec, string& tekst);
void zadanie5_2(string wzorzec, string tekst);
void zadanie5_3(string wzorzec, string tekst);
void zadanie5_4(string wzorzec, string tekst);
void tablicaPrzesuniec(string wzorzec, int dlw, int *p, int pocz, int kon);
void bm(string wzorzec, string tekst, int dlw, int dlt, int *p, int pocz);
void zbudujTabliceDopasowan(string wzorzec, int dlw, int *p);
void kmp(string wzorzec, string tekst, int dlw, int dlt, int *p);

void zadanie5_1(string& wzorzec, string& tekst){
    cout<<"Podaj tekst ";
    cin.ignore();
    getline(cin, tekst);
    cout<<"Podaj wzorzec ";
    cin.ignore();
    getline(cin, wzorzec);
}

void zadanie5_2(string wzorzec, string tekst) {
    int j, i;
    i = 0;
    while (i <= ((tekst.length()) - (wzorzec.length()))) {
        j = 0;
        while (j < wzorzec.length() && wzorzec[j] == tekst[i + j]) {
            j++;
        }
        if (j == wzorzec.length()) {
            cout << i << " ";
        }
        i++;
    }
}

void zadanie5_4(string wzorzec, string tekst){
    int dlw, dlt, pocz, kon;
    dlw=wzorzec.length();
    dlt=tekst.length();
    int *p1 = new int[256];
    pocz=wzorzec[0];
    kon=wzorzec[dlw];
    tablicaPrzesuniec(wzorzec, dlw, p1, pocz, kon);
    bm(wzorzec, tekst, dlw, dlt, p1, pocz);

}

void bm(string wzorzec, string tekst, int dlw, int dlt, int *p1, int pocz){
    int n_pocz, i, j;
    n_pocz=(int)pocz;
    i=0;
    while (i<=dlt-dlw){
        j=dlw-1;
        while((j>-1)&&(wzorzec[j]==tekst[i+j])) j--;
        if (j==-1){
            cout<<i<<" ";
            i++;
        }
        else i=i+max(1,j-p1[tekst[i+j]-n_pocz]);
    }
}

void tablicaPrzesuniec(string wzorzec, int dlw, int *p1, int pocz, int kon){
    int n_pocz, n_kon, i;
    n_pocz=(int)pocz;
    n_kon=(int)kon;
    i=0;
    while (i<=n_kon-n_pocz){
        p1[i]=-1;
        i++;
    }
    i=0;
    while(i<dlw){
        p1[wzorzec[i]-n_pocz]=i;
        i++;
    }
}

void zadanie5_3(string wzorzec, string tekst){
    int dlw, dlt;
    dlw=wzorzec.length();
    dlt=tekst.length();
    int *p = new int[dlw+1];
    zbudujTabliceDopasowan(wzorzec, dlw, p);
    kmp(wzorzec, tekst, dlw, dlt, p);
}

void kmp(string wzorzec, string tekst, int dlw, int dlt, int *p){
    int i,j;
    i=0;
    j=0;
    while (i<(dlt-dlw+1)){
        while ((wzorzec[j]==tekst[i+j])&&(j<dlw)) j++;
        if (j==dlw) cout<<i<<" ";
        i=i+max(1,j-p[j]);
        j=p[j];
    }
}

void zbudujTabliceDopasowan(string wzorzec, int dlw, int *p){
    p[0]=0;
    p[1]=0;
    int t, i;
    t=0;
    i=1;
    while(i<dlw){
        while ((t>0)&&(wzorzec[t]!=wzorzec[i])) t=p[t];
        if (wzorzec[t]==wzorzec[i]) t++;
            p[i+1]=t;
            i++;

    }
}

int main()
{
    string wzorzec, tekst;
    int algorytm;
    algorytm = 1;
    while(algorytm!=-1){
    cout<<"1 - Wczytanie tekstu"<<endl;
    cout<<"2 - Naiwny algorytm wyszukiwania"<<endl;
    cout<<"3 - Algorytm Knutha-Morrisa-Pratta"<<endl;
    cout<<"4 - Algorytm Boye'a-Moore'a"<<endl;
    cout<<"Co chcesz zrobic ? Wprowadz cyfru ";
    cin>>algorytm;
    cout<<endl;
    if (algorytm==1){
        zadanie5_1(wzorzec, tekst); //wczytanie
        cout<<"Zostalo wczytano"<<endl;
        cout<<endl;}
    else{
        if (algorytm == 2){
            cout<<"Znalezono wystapienie na pozycjach(numeracja od 1) :";
            zadanie5_2(wzorzec, tekst); //algorytm naiwny
            cout<<endl;}

        else{
            if (algorytm == 3){
                cout<<"Znalezono wystapienie na pozycjach(numeracja od 1) :";
                zadanie5_3(wzorzec, tekst); //algorytm Knutha-Morrisa-Pratta
                cout<<endl;
            }
            else{
                if (algorytm == 4){
                    cout<<"Znalezono wystapienie na pozycjach(numeracja od 1) :";
                    zadanie5_4(wzorzec, tekst); //algorytm Boye'a-Moore'a
                    cout<<endl;
                }
                else{
                    cout<<"Nie ma takiego zadania "<<endl;
                    algorytm = -1;
                    }
                }
            }
        }
    }
    return 0;
}
